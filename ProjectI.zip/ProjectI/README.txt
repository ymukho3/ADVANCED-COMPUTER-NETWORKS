Project: 'ProjectI' created on 2025-01-13
Author: John Doe <john.doe@example.com>

No project description was given